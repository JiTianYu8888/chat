<?php


define('UC_CONNECT', 'mysql');
define('UC_STANDALONE', 0);

define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'freeiihbuvvy');
define('UC_DBPW', 'admin');
define('UC_DBNAME', 'freeiihbuvvy');
define('UC_DBCHARSET', 'utf8mb4');
define('UC_DBTABLEPRE', '`freeiihbuvvy`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_AVTURL', '');
define('UC_AVTPATH', '');

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'n37aA2S9GbO0Zfv440I4i3N57cWfF6zf7fCd88Q2I4g0a1s7h9e7f1za04D0Lfc9');
define('UC_API', 'http://gt.sdos.top/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>