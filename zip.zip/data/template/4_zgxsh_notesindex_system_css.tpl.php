<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<link rel="stylesheet" href="source/plugin/zgxsh_notesindex/template/css/element/index.css" />
<script src="source/plugin/zgxsh_notesindex/template/css/vue.global.js" type="text/javascript" charset="utf-8"></script>
<script src="source/plugin/zgxsh_notesindex/template/css/element/index.full.js" type="text/javascript" charset="utf-8"></script>


<script type="text/javascript">var STYLEID = '<?php echo STYLEID;?>', STATICURL = '<?php echo STATICURL;?>', IMGDIR = '<?php echo IMGDIR;?>', VERHASH = '<?php echo VERHASH;?>', charset = '<?php echo CHARSET;?>', discuz_uid = '<?php echo $_G['uid'];?>', cookiepre = '<?php echo $_G['config']['cookie']['cookiepre'];?>', cookiedomain = '<?php echo $_G['config']['cookie']['cookiedomain'];?>', cookiepath = '<?php echo $_G['config']['cookie']['cookiepath'];?>', showusercard = '<?php echo $_G['setting']['showusercard'];?>', attackevasive = '<?php echo $_G['config']['security']['attackevasive'];?>', disallowfloat = '<?php echo $_G['setting']['disallowfloat'];?>', creditnotice = '<?php if($_G['setting']['creditnotice']) { ?><?php echo $_G['setting']['creditnames'];?><?php } ?>', defaultstyle = '<?php echo $_G['style']['defaultextstyle'];?>', REPORTURL = '<?php echo $_G['currenturl_encode'];?>', SITEURL = '<?php echo $_G['siteurl'];?>', JSPATH = '<?php echo $_G['setting']['jspath'];?>', CSSPATH = '<?php echo $_G['setting']['csspath'];?>', DYNAMICURL = '<?php echo $_G['dynamicurl'];?>';</script>
<script src="<?php echo $_G['setting']['jspath'];?>common.js?<?php echo VERHASH;?>" type="text/javascript"></script>

<div id="append_parent"></div>
<div id="ajaxwaitid"></div>

<style>
body {
margin: 0px;
background-image: url(source/plugin/zgxsh_notesindex/template/img/index/b.jpg);
background-size: 100% 100%;
        overflow-y: hidden;
}

    /*底部菜单*/
    .foo_cd{
        text-align: center;
        font-size: 14px;
        cursor: pointer;
    }
    .foo_cd > img{
        width: 26px;height: 26px
    }
    .foo_cd > span{

    }
    .cd_i > span{
        color: #333;
        font-weight: 600;
        text-shadow: 1px 1px 0px #ccc;
    }
    .cd_i > img{
        filter: brightness(50%) !important;
        filter: drop-shadow(1px 1px 0px #ccc);
    }
    /*顶部返回*/
    .return_css{
        cursor: pointer;
    }
    .return_css:hover{
        filter: drop-shadow(0px 0px 2px #333);
    }



    /*罗盘列表*/
    .compass_list{
        border-radius: 8px;
        height: 80px;
        border: 2px #eee solid;
        box-shadow: 1px 1px 2px rgba(0,0,0,0.4);
        display: flex;
        align-items: center;
        padding: 0px 10px;
        background-color: #fff;
        margin: 8px 0px;
        cursor: pointer;
    }
    .new{
        justify-content: center !important;
        color: #aaa;
        background-color: rgba(0,0,0,0);
        border: 2px #aaa dashed;
        box-shadow: 0px 0px 0px rgba(0,0,0,0.4);
    }
    .compass_list:hover{
        box-shadow: 1px 1px 8px rgba(0,0,0,0.4);
        text-shadow: 1px 1px 8px rgba(0,0,0,0.4);
    }
</style>