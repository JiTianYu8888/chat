<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<el-header style="font-size: 18px;padding: 8px 14px;display: flex;justify-content: space-between;height: 40px;align-items: center">
    <div>
        <b><?php echo $_TRC['p_name'];?></b>
        <span style="font-size: 10px;color: 888;margin-left: 6px">v<?php echo $_G['setting']['plugins']['version']['zgxsh_notesindex'];?></span>
    </div>
    <div>
        <span style="font-size: 10px;color: 888"><?php echo $_TRC['sys_ext_title'];?>: <?php echo $_TRC['sys_ext_num'];?> <?php echo $_TRC['sys_ext_unit'];?></span>
        <?php echo $_G['username'];?>
        <img src="<?php echo avatar($_G['uid'],'',1);?>" style="width: 24px;height: 24px;border-radius: 4px;border: 2px solid #fff;">
    </div>
</el-header>