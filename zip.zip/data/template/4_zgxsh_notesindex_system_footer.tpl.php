<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<el-footer style="font-size: 18px;padding: 8px 14px;box-shadow: 0px -1px 2px rgba(0,0,0,0.2);">
    <div class="foo_cd" onclick="location='/'">
        <img src="source/plugin/zgxsh_notes/template/img/index/ico5.png">
        <br>
        <span>返回论坛</span>
    </div>
</el-footer>