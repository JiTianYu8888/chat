<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');?>
<link rel="stylesheet" type="text/css" href="<?php echo $_G['setting']['csspath'];?>4_common.css?<?php echo VERHASH;?>" /><?php if($_G['uid'] && isset($_G['cookie']['extstyle']) && strpos($_G['cookie']['extstyle'], TPLDIR) !== false) { ?><link rel="stylesheet" id="css_extstyle" type="text/css" href="<?php echo $_G['cookie']['extstyle'];?>/style.css?<?php echo VERHASH;?>" /><?php } elseif($_G['style']['defaultextstyle']) { ?><link rel="stylesheet" id="css_extstyle" type="text/css" href="<?php echo $_G['style']['defaultextstyle'];?>/style.css?<?php echo VERHASH;?>" /><?php } ?><!--[if IE]><link rel="stylesheet" type="text/css" href="data/cache/style_4_iefix.css?<?php echo VERHASH;?>" /><![endif]--><?php include template('common/header_common'); ?><div id="append_parent"></div>
<div id="ajaxwaitid"></div>

<style type="text/css">

</style>

<!--[内容]-->
<div style="background-color: #fff;height: 100%;width: 100%;min-height: 700px;min-width:600px;margin: auto;" id="app">

<el-container style="height: 100%;">

        <?php include template('zgxsh_notesindex:system/header'); ?><el-main style="background-color: #efefef;box-shadow: 0px 1px 2px rgba(0,0,0,0.2) inset;">
            <div style="display: flex;justify-content: center">

                <el-card :body-style="{ padding: '0px'}" style="margin: 10px;cursor: pointer;width: 280px;" shadow="hover"
                         onclick="location='plugin.php?id=zgxsh_notes:index'"
                >
                    <el-image style="width: 280px; height: 280px" src="source/plugin/zgxsh_notesindex/template/img/index/01.jpg" fit="cover" ></el-image>
                    <div style="padding: 14px;text-align: center;">
                        <div><span style="font-size: 18px">罗盘笔记</span></div>
                        <div style="color: #888;font-size: 14px">
                            罗盘结构的笔记系统 , 适合科研探索 , 试验记录等多种用途
                        </div>
                    </div>
                </el-card>

                <el-card :body-style="{ padding: '0px'}" style="margin: 10px;cursor: pointer;width: 280px;" shadow="hover"
                         onclick="location='plugin.php?id=zgxsh_notestree:index'"
                >
                    <el-image style="width: 280px; height: 280px" src="source/plugin/zgxsh_notesindex/template/img/index/02.jpg" fit="cover" ></el-image>
                    <div style="padding: 14px;text-align: center;">
                        <div><span style="font-size: 18px">树状笔记</span></div>
                        <div style="color: #888;font-size: 14px">
                            常规的树状目录结构笔记系统 , 适合普通笔记用户
                        </div>
                    </div>
                </el-card>

            </div>
</el-main>

        <?php include template('zgxsh_notesindex:system/footer'); ?></el-container>

</div>
<!--[内容]--><?php include template('zgxsh_notesindex:system/css'); ?><script lang="ts">

const { defineComponent, h } = Vue;
const { ElMessageBox, ElMessage } = ElementPlus;

const App = {
data() {
return {
activeName: "1",			
}
},
methods: {
    }
};

const app = Vue.createApp(App);
app.use(ElementPlus);
app.config.warnHandler = () => null;  // 屏蔽警告信息
const trc = app.mount("#app");

</script>