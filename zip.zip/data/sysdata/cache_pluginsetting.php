<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 49ea93381b977c27093d1f1758489791

$pluginsetting = array (
);
?>